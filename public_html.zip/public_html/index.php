<!DOCTYPE html>
<html>
    <head>
        <title>Проектирование архитектуры корпоративных информационных систем</title>
    </head>
        <ol>
            <li><a href="lab1/index.php">Лабораторная работа № 1 - Классы и интерфейсы</a></li>
        </ol>
</html>