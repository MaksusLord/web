<!DOCTYPE html>
<html>
    <head>
        <title>Лабораторная работа № 1 - "Классы и интерфейсы"</title>
    </head>
    <body>
        <ol>
            <li><a href="users.php">users</a></li>
        </ol>
    </body>
</html>