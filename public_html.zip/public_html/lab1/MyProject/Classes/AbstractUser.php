<?php

namespace MyProject\Classes;

abstract class AbstractUser {
    abstract public function showInfo();
}
?>