<!DOCTYPE html>
<html>
    <head>
        <title>Проектирование архитектуры корпоративных информационных систем</title>
    </head>
        <ol>
            <li><a href="Number2/settings_use.php">Задание 2</a></li>
            <li><a href="Number3/factory_use.php">Задание 3</a></li>
            <li><a href="Number3/factory-method.html">Задание 3 - диаграмма</a></li>
            <li><a href="Number4/mvc_use.php">Задание 4</a></li>
            <li><a href="Number4/factory-method.html">Задание 4 - диаграмма</a></li>
        </ol>
</html>