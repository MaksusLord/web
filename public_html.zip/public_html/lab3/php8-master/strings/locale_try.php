<?php
$loc = setlocale(LC_ALL, 'ru', 'ru_RU', 'rus', 'russian');
echo "На этой системе русская локаль имеет имя '$loc'";
