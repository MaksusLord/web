<?php
echo '<pre>';
printf('% 5d\n', 45); // '   45'
printf('%05d\n', 45); // '00045'
echo '</pre>';
