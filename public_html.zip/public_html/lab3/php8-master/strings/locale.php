<?php
echo setlocale(LC_ALL, 0); // ru_RU.UTF-8
