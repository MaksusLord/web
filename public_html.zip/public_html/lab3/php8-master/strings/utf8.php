<?php
echo "\u{0410}"; // А
