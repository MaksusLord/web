<?php
$str = 'PHP - интерпретируемый язык';
echo substr($str, strpos($str, 'интер')); // интерпретируемый язык
