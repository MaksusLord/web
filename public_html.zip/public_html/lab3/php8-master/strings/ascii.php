<?php
for ($code = 32; $code < 128; $code++) {
    echo "code ($code) = " . chr($code) . '<br />';
}
