<?php
setlocale(LC_ALL, 'ru_RU.UTF-8');

echo '<pre>';
print_r(localeconv());
echo '</pre>';
