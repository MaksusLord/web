<?php
echo setlocale(LC_MONETARY, 'ru_RU.UTF-8');
