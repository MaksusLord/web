<?php
$str = 'Hello world';
echo "{$str[2]}<br />";

$str = 'Привет мир!';
echo "{$str[2]}<br />";
