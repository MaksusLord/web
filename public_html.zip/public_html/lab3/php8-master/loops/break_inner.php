<?php
$i = 0;
while (true)
{
    while (true)
    {
        while (true)
        {
            $i++;
            if ($i > 5) break 3;
            echo "$i<br />";
        }
    }
}
