<?php
for ($i = 6, $j = 0;
     $i != $j;
     print "$i - $j", print '<br />', $i--, $j++);
