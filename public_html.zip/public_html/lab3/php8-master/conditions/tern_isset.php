<?php
$x = isset($x) ?: 1;
echo $x; // 1
