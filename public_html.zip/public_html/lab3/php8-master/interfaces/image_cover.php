<?php
require_once 'image.php';
interface Cover extends Image {}
