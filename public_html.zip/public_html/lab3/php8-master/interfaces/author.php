<?php
interface Author
{
    public function setAuthor(array $authors) : void;
    public function getAuthor() : array;
}
