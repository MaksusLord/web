<?php
    echo "Hello, php!";
?>
