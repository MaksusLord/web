<?php
    echo1 "Hello, world!";
?>
