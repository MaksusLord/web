<?php
namespace PHP8;

echo __NAMESPACE__; // PHP8
