<?php
namespace PHP8;

require_once 'namespaces.php';
$page = new classes\Page('Контакты', 'Содержимое страницы');
functions\debug($page);
