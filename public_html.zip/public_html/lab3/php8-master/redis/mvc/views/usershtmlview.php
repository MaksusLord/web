<?php
namespace MVC\Views;

class UsersHtmlView extends HtmlView {}
