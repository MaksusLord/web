<?php
$arr = timezone_abbreviations_list();
echo '<pre>';
print_r($arr['eest']);
echo '</pre>';
