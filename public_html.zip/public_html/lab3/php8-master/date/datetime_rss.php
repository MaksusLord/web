<?php
$date = new DateTime('2023-01-01 00:00:00');
echo $date->format(DateTime::RSS); // Sun, 01 Jan 2023 00:00:00 +0000
