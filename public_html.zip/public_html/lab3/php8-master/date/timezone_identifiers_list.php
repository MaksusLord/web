<?php
echo '<pre>';
print_r(timezone_identifiers_list());
echo '</pre>';
