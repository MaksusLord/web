<?php
$time = microtime(true);
printf('С начала эпохи UNIX: %f секунд.<br />', $time);
echo "С начала эпохи UNIX: $time секунд.<br />";
