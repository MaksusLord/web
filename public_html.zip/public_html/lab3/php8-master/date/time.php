<?php
echo time(); // 1652604785
