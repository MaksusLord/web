<?php
$date = new DateTime();
echo $date->format('d-m-Y H:i:s'); // 16-05-2022 19:04:20
