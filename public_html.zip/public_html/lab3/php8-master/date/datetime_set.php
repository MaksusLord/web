<?php
$date = new DateTime('2023-01-01 00:00:00');
echo $date->format('d.m.Y H:i:s'); // 01.01.2023 00:00:00
