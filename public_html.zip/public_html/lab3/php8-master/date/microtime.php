<?php
echo microtime();      // 0.72600800 1652605301
echo '<br />' . PHP_EOL;
echo microtime(true);  // 1652605301.726
