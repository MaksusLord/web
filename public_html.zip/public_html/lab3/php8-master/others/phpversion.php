<?php
echo phpversion(); // 8.1.4
