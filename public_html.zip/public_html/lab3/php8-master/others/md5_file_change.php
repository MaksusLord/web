<?php
echo md5_file($_SERVER['PHP_SELF']); // 733b230e574c4e8a187678d0a20d60dd
