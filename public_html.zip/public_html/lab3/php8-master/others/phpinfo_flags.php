<?php
phpinfo(INFO_CREDITS | INFO_LICENSE);
