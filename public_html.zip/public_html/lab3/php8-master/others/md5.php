<?php
$str = 'Какая-то произвольная строка';
echo md5($str); // 169dd0040cbdab4cac1e8de55d951206
