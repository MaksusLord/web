<?php
echo md5_file($_SERVER['PHP_SELF']);
