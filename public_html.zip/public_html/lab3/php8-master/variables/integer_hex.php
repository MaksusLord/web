<?php
echo 0xffcc00; // 16763904
