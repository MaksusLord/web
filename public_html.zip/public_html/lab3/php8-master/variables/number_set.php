<?php
$number = 1;
$var = 3.14;
