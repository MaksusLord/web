<?php
$var = null;
echo $var;
echo $arr;