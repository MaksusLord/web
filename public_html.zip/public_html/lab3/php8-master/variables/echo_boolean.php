<?php
echo true;  // "1"
echo false; // ""
