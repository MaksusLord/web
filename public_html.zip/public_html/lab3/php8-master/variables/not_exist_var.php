<?php
echo $var; // PHP Warning:  Undefined variable $var
