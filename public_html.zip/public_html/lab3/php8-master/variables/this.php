<?php
$this = 'this.php'; // PHP Fatal error:  Cannot re-assign $this
