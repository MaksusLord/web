<?php
$b = true;
echo "b: $b<br />";
$b++;
echo "b: $b<br />";
