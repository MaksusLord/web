<?php
$num = $number = $var = 1;
