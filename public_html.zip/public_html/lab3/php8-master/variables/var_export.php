<?php
$arr = [
    1,
    [
        "Programs hacking programs. Why?",
        "д'Артаньян"
    ]
];
echo "<pre>";
var_export($arr);
echo "</pre>";

class SomeClass
{
    private $x = 100;
}
$obj = new SomeClass();
echo "<pre>";
var_export($obj);
echo "</pre>";
