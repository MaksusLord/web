<?php
$arr = [
    'a'=>'apple',
    'b'=>'banana',
    'c'=> ['x', 'y', 'z']
];

echo "<pre>";
print_r($arr);
echo "</pre>";
