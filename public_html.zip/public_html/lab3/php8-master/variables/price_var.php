<?php
$price = 3000;
$price_vip = $price + 500;
echo "Цена билета: $price<br />";                      # 3000
echo "Цена билета на хорошее место: $price_vip<br />"; # 3500
