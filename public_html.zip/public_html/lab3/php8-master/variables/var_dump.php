<?php
$arr = [
    1,
    ["a", "b"]
];

echo "<pre>";
var_dump($arr);
echo "</pre>";
