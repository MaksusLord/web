<?php
echo 0755;  // 493
echo 0o755; // 493
