<?php
echo 1.8e307;  // 1.8E+307
echo 1.8e308;  // INF
echo -1.8e308; // -INF
