<?php
$price = 3000;
$price_vip = $price + 500;
$price_vip = "неизвестно";
echo $price_vip; // неизвестно
