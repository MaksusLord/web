<?php
$first = 1;
$second = 2;
echo $first + $second; // 3

$greeting = 'Hello, ';
$subject = 'PHP!';
echo $greeting . $subject; // Hello, PHP!
echo $greeting + $subject; // Fatal error: Uncaught TypeError: Unsupported operand types: string + string