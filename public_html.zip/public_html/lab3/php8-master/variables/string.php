<?php
$str = "Hello, world!";
echo $str;
