<?php
$str = '12.6';
$number = 3 + $str;
echo $number; // 15.6
