<?php
$str = 'Hello, world!';
echo $str[0]; // H
