<?php
$str = "Hello, world!";
echo "$str[2]$str[4]$str[9]$str[11]"; // lord
