<?php
$bool = true;
