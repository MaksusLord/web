<?php
// Объявляем вещественную переменную
$double = 4.863;
// Преобразуем переменную $float к целому типу
$number = (int)$double;

echo $number; // 4
