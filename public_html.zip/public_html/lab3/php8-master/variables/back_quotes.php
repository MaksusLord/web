<?php
// echo `ls -l`; // UNIX
echo `dir`;      // Windows
