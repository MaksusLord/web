<?php
$str = 'Hello, world!';
echo $str[13]; // PHP Warning:  Uninitialized string offset 13
