<?php
$echo = 'echo';
$foreach = 'foreach';
echo $echo;
echo $foreach;
