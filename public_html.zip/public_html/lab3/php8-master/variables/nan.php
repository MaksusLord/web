<?php
echo sqrt(-1); // NAN
