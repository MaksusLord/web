<?php
echo 0b1010101; // 85