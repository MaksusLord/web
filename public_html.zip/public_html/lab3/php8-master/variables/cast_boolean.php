<?php
$float = 0.0;
if ($float) { // false
    echo 'Переменная $float рассматривается как true';
}

$str = "Hello, world!";
if ($str) { // true
    echo 'Переменная $str рассматривается как true';
}
