<?php
require_once('readonly.php');

$object = new Greeting;
echo $object->hello;
