<?php
require 'point.php';

$point = new Point;
$point->x = 3;
$point->y = 7;

echo '<pre>';
print_r($point);
echo '</pre>';