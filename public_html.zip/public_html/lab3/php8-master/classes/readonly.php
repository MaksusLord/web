<?php
class Greeting {
    public readonly string $hello;
}
