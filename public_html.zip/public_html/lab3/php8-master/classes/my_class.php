<?php
class MyClass
{
    // Свойства класса
}
