<?php
$date = new DateTime();
echo get_class($date); // DateTime
echo $date::class;     // DateTime
