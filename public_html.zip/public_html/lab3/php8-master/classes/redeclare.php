<?php
class Point
{
    public $x;
    public $y;
}

// PHP Fatal error:  Cannot declare class Point, because the name is already in use
class Point
{
}
