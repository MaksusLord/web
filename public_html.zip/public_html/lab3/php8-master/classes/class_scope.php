<?php
require 'point.php';
// class Point
// {
//     public $x;
//     public $y;
// }
$point = new Point;
echo $x; // PHP Warning:  Undefined variable $x
