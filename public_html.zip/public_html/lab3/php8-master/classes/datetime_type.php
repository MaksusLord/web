<?php
$date = new DateTime();
echo gettype($date); // object
echo get_class($date); // DateTime
