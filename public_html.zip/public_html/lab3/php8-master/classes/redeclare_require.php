<?php
require 'point.php';
/*
...
Очень много кода
...
*/
require 'point.php'; // PHP Fatal error:  Cannot declare class Point
