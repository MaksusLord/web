<?php
require 'point.php';

$point = new Point;
var_dump($point->x); // NULL
