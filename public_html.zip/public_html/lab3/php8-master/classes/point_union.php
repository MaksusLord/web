<?php
class Point
{
    public int|float $x;
    public int|float $y;
}
