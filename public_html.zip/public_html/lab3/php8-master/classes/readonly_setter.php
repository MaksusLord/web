<?php
class Greeting {
    public readonly string $hello;
    public function setter() {
        $this->hello = 'PHP';
   }
}
