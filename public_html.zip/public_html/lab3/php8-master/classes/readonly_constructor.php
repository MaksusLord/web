<?php
class Greeting {
    public readonly string $hello;
    public function __construct() {
        $this->hello = 'PHP';
   }
}
