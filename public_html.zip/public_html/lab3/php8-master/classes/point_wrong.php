<?php
require 'point.php';

$point = new Point;
$point->x = 'примерно четыре';
$point->y = 'неизвестно';

echo $point->x; // примерно четыре
