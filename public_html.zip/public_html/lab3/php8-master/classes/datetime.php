<?php
$date = new DateTime();
echo $date->format('d-m-Y H:i:s');
