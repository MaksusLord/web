<?php
class Greeting {
    public readonly mixed $hello;
}
