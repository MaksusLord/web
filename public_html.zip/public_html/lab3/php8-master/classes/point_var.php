<?php
require 'point.php';

$point = new Point();
$point = 3;

echo $point; // 3
