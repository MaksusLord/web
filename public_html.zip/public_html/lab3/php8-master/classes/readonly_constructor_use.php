<?php
require_once('readonly_constructor.php');

$object = new Greeting;
echo $object->hello; // PHP
