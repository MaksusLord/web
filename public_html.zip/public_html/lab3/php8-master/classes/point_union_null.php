<?php
class Point
{
    public int|null $x;
    public int|null $y;
}
