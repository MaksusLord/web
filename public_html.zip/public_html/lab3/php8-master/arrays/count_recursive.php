<?php
$arr = [
           [1, 2, 3, 4],
           [5, 6, 7, 8]
       ];
echo count($arr, COUNT_RECURSIVE); // 10
