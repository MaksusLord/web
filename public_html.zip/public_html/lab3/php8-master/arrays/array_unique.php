<?php
$arr = ['a' => 'green', 'red', 'b' => 'green', 'blue', 'red'];
$result = array_unique($arr);

echo '<pre>';
print_r($result);
echo '</pre>';
