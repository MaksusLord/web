<?php
$arr = [1, 2, 3];
list($one, $two, $three) = $arr;
echo $one;   // 1
echo $two;   // 2
echo $three; // 3
