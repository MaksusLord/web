<?php
$arr = ['size' => 'XL', 'color' => 'gold'];
$num = array_values($arr);

echo '<pre>';
print_r($num);
echo '</pre>';
