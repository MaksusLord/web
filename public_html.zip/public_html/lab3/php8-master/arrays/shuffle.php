<?php
$arr = [1, 2, 3, 4, 5];
shuffle($arr);

echo '<pre>';
print_r($arr);
echo '</pre>';
