<?php
$arr = ['blue', 'red', 'green', 'blue', 'blue'];
$key = array_keys($arr, 'blue');

echo '<pre>';
print_r($key);
echo '</pre>';
