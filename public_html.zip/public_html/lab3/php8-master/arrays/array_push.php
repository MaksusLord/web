<?php
$arr = ['красный', 'синий'];
array_push($arr, 'зеленый');

echo '<pre>';
print_r($arr);
echo '</pre>';
