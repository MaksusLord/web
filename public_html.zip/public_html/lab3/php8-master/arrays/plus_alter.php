<?php
$fst = [0 => 'one', 1 => 'two'];
$snd = [0 => 'three', 1 => 'four', 2 => 'five'];
$sum = $fst + $snd;
echo '<pre>';
print_r($sum);
echo '</pre>';
