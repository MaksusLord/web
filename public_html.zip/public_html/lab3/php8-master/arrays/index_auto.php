<?php
$arr[] = 'Hello, ';
$arr[] = 'world';
$arr[] = '!';
echo '<pre>';
print_r($arr);
echo '</pre>';
