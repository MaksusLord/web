<?php
$langs = ['PHP', 'Python', 'Ruby', 'JavaScript'];
echo count($langs); // 4
