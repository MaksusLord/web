<?php
$arr = [0 => 100, 'color' => 'red'];
$key = array_keys($arr);

echo '<pre>';
print_r($key);
echo '</pre>';
