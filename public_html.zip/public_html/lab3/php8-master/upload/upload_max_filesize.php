<?php
echo ini_get('upload_max_filesize'); // 2M
