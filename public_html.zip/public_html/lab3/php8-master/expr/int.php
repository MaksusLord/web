<?php
echo (int)(5 / 3); // 1
