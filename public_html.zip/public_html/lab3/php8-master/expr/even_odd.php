<?php
$number = 5317;
if ($number % 2) echo 'Число не четное';
else echo 'Число четное';
