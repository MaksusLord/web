<?php
$zero = 10;
$tsss = '10';
if ($zero === $tsss) echo 'переменные эквиваленты';
