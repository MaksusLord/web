<?php
echo 'Hello, php!' > 'Hello, world!'; // false
echo 'Hello, php!' < 'Hello, world!'; // true
