<?php
echo 'Hello, world!';
echo('Hello, world!');
