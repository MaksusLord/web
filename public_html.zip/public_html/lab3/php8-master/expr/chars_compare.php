<?php
echo 'a' > 'b'; // false
echo 'a' < 'b'; // true
