<?php
echo '3.14' + 3.14;
