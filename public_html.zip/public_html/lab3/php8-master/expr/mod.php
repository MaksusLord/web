<?php
echo 5 % 3; // 2
echo 6 % 3; // 0
