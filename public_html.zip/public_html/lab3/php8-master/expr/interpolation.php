<?php
$number = 216;
echo "Сегодня $number участников";
echo "Сегодня {$number} участников";
