<?php
$number = 216;
echo('Сегодня ', $number, ' участников');
// PHP Parse error:  syntax error, unexpected token ","
