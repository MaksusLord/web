<?php
$hundred = 100;
if ($hundred == 1)    echo 'хм, странно... переменная равна 1!<br />';
if ($hundred == true) echo 'переменная истинна!<br />';
