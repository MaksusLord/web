<?php
echo 'Значение = ' + 3.14;
// PHP Fatal error: Uncaught TypeError: Unsupported operand types: string + float
