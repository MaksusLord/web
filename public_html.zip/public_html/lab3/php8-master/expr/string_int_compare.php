<?php
$int = 10;
$string = '10';
if ($int == $string) echo 'переменные равны';
