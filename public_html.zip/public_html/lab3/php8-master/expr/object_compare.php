<?php
class AgentSmith {}
$smit = new AgentSmith();
$wesson = new AgentSmith();
echo ($smit == $wesson);
