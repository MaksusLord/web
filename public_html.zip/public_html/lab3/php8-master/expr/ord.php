<?php
echo ord('a'); // 97
echo ord('b'); // 98
