<?php
echo sqrt(4) . '<br />'; // 2

$result = sqrt(4);
echo "$result<br />"; // 2

$x = 3;
$y = 5;
$distance = sqrt($x * $x + $y * $y);
echo $distance; // 5.8309518948453
