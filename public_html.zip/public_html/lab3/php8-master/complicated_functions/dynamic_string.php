<?php
echo 'rand'();
