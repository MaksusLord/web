<?php
echo getcwd();
