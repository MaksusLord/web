<?php
mkdir('hello/world', recursive: true);
