<?php
mkdir('hello/world');
