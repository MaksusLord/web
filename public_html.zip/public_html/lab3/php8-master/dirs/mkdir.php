<?php
mkdir('test', 0770);
mkdir('/data');
