<?php
header('location: https://php.net');
