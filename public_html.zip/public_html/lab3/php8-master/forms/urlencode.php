<?php
$phrase = urlencode('Привет, мир!');
echo "<a href='test.php?phrase=$phrase'>ссылка</a>";
